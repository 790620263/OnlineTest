//#include<iostream>
//#include<iomanip>
//using namespace std;
//void print(int num);
//int main()
//{
//	print(12);
//}
//void print(int num)
//{
//	for (int i = 1; i < num + 1;i++)
//	{
//		cout << setw(5) << i;
//	}
//	cout <<endl<< setw(5) <<"+";
//	for (int i = 1; i < num + 1; i++)
//	{
//		cout << "-----";
//	}
//	
//	for (int row = 1; row < num + 1; row++)
//	{
//		cout <<endl<< row;
//		for (int col = 1; col < num + 1; col++)
//		{
//			cout << setw(5) <<row*col;
//		}
//	}
//}