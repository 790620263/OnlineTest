//#include<iostream>
//using namespace std;
//int main()
//{
//	string theInput;
//
//	while (true) {
//		cin.clear();
//		cin.ignore(1024, '\n');
//		cin >> theInput;
//		cout << theInput<<endl;
//	}
//}