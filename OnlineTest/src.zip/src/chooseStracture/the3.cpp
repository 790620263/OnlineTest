/**
编程实现输出1--100之间能被7整除但不能被3整除的所有偶数，
并求满足该条件的所有数的累加和。
**要求输入提示信息为：无输入提示信息和输入数据
**要求输出格式为：（1）"%5d"  
                  （2）"\nsum=%d\n"*/
//#include <iostream>
//using namespace std;
//int main()
//{
//    int sum = 0;
//    for (int i = 1; i < 51; i++)
//    {
//        if (2 * i % 7 == 0 && 2 * i % 3 != 0)
//        {
//            sum = sum + 2 * i;
//            printf("%5d", 2 * i);
//        }
//    }
//    printf("\nsum=%d\n", sum);
//}