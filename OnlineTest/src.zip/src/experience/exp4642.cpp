/*
#include<iostream>
using namespace std;
void printn(string str, int time);
int main()
{
	int charNum = 1;
	for (int i = 1; i <= 5; i++)
	{
		printn(" ", 5 - i);
		printn("#", 2 * i - 1);
		printn(" ", 5 - i);
		cout << endl;
	}
}
void printn(string str, int time)
{
	for (int i = 0; i < time; i++)
	{
		cout << str;
	}
}*/